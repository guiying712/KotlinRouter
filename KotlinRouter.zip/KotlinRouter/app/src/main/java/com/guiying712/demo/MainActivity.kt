package com.guiying712.demo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.guiying712.annotations.Router
import kotlinx.android.synthetic.main.activity_main.*

@Router("/main")
class MainActivity : AppCompatActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    // Switch to AppTheme for displaying the activity
    setTheme(R.style.AppTheme)

    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    recyclerView.apply {
      layoutManager = LinearLayoutManager(this@MainActivity)
    }
  }
}
