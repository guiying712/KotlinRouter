package com.guiying712.demo

import android.graphics.Rect
import android.os.Bundle
import android.view.TouchDelegate
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.guiying712.annotations.Router

@Router("/main")
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Post in the parent's message queue to make sure the parent
        // lays out its children before you call getHitRect()
        findViewById<View>(R.id.parent_layout).post {
            // The bounds for the delegate view (an ImageButton
            // in this example)
            val delegateArea = Rect()
            val myButton = findViewById<ImageButton>(R.id.button).apply {
                isEnabled = true
                setOnClickListener {
                    Toast.makeText(
                        this@MainActivity,
                        "Touch occurred within ImageButton touch region.",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                // The hit rectangle for the ImageButton
                getHitRect(delegateArea)
            }

            // Extend the touch area of the ImageButton beyond its bounds
            // on the right and bottom.
            delegateArea.right += 100
            delegateArea.bottom += 100

            // Sets the TouchDelegate on the parent view, such that touches
            // within the touch delegate bounds are routed to the child.
            (myButton.parent as? View)?.apply {
                // Instantiate a TouchDelegate.
                // "delegateArea" is the bounds in local coordinates of
                // the containing view to be mapped to the delegate view.
                // "myButton" is the child view that should receive motion
                // events.
                touchDelegate = TouchDelegate(delegateArea, myButton)
            }
        }
    }

//    override fun getResources(): Resources {
//        val appDisplayMetrics = application.resources.displayMetrics
//        application.registerComponentCallbacks(object : ComponentCallbacks {
//            override fun onConfigurationChanged(newConfig: Configuration) {
//                if (newConfig.fontScale > 0) {
//                    application.resources.displayMetrics.scaledDensity
//                }
//            }
//
//            override fun onLowMemory() {
//                TODO("Not yet implemented")
//            }
//        })
//
//        val activityDisplayMetrics = this.resources.displayMetrics
//        return super.getResources()
//    }

}


