package com.guiying712.demo

import com.guiying712.router.RouterAnnotationHandler

class LoaderInit {

//    fun init() {
//        val init = AnnotationInit_2b892ad168ed4049a3c957b34ef188a6()
//        init
//    }
}