package com.guiying712.router

interface RouterAnnotationInit {

    fun init(handler: RouterAnnotationHandler)

}