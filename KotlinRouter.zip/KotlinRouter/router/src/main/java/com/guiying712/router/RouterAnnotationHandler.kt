package com.guiying712.router

interface RouterAnnotationHandler {

    fun register(url: String, target: String)

}