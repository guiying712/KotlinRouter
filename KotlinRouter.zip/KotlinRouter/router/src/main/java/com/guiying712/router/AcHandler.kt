package com.guiying712.router

class AcHandler : RouterAnnotationInit {

    override fun init(handler: RouterAnnotationHandler) {

    }
}